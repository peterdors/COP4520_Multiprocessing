This will hold the sequential implementations of our Linked List data structure.

To compile the C++ implementation from your terminal or command line, run the
provided run.sh bash file by making the following call from your terminal:

bash run.sh

This program was ran and tested using a MacOS Mojave version 10.14.6 and using
the g++ compiler clang version clang-1001.0.46.4 and C++11
