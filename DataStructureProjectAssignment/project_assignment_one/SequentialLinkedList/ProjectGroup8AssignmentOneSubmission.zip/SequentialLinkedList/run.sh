g++ -std=c++11 -pthread SequentialLinkedList.cpp && ./a.out
