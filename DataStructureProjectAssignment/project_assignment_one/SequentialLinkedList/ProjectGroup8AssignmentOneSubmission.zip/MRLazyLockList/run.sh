g++ -std=c++11 -pthread MRLazyLockList.cpp && ./a.out
