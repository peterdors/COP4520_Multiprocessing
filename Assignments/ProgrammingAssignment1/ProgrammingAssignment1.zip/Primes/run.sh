
#!/bin/bash

# This script is just for running the primes.cpp program quickly and easily.
g++ -std=c++11 -pthread primes.cpp && ./a.out

